var numRows = 10;
var numCols = 10;
var tableContainer = document.getElementById('table-container');
var table = document.createElement('table');
for (var i = 0; i < numRows; i++) {
    var row = document.createElement('tr');
    for (var j = 0; j < numCols; j++) {
        var cell = document.createElement('td');
        var imagem = document.createElement('img');
        imagem.src = '/imgs/Fire-icon.png';
        cell.appendChild(imagem);
        row.appendChild(cell);
    }
    table.appendChild(row);
}
tableContainer.appendChild(table);