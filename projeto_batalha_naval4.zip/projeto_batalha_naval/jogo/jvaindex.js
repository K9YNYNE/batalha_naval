
        // Coloque aqui o código JavaScript para criar a tabela com imagens
        var numRows = 9;
        var numCols = 9;

        var tableContainer = document.getElementById('table-container');
        var table = document.createElement('table');

        for (var i = 0; i < numRows; i++) {
            var row = document.createElement('tr');
            for (var j = 0; j < numCols; j++) {
                var cell = document.createElement('td');
                var imagem = document.createElement('img');
                imagem.src = 'Fire-icon.png';
                (function (i, j) {
                    imagem.onclick = function () {
                        teste_tiro(i, j);
                    };
                })(i, j);
                cell.appendChild(imagem);
                row.appendChild(cell);
            }
            table.appendChild(row);
        }

        tableContainer.appendChild(table);